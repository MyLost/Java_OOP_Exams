package zoo.entities.foods;

public interface Food {
    int getCalories();

    double getPrice();
}
