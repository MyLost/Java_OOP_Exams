package zoo.entities.foods;

public class Vegitable extends BaseFood {

    private static final int CALIRIES = 50;
    private static final double PRICE = 5.00;

    public Vegitable() {
        super(CALIRIES, PRICE);
    }
}
